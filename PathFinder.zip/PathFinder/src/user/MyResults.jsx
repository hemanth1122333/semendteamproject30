function MyResults() {
  return (
    <div>
      <h2 className="form-title">My Results</h2>
      <p>Your assessment results will appear here.</p>
    </div>
  );
}

export default MyResults;
