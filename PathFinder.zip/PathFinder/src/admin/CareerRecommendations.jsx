function CareerRecommendations() {
  return (
    <div>
      <h2 className="form-title">Career Recommendations</h2>
      <p>Admin can update and modify career suggestions here.</p>
    </div>
  );
}

export default CareerRecommendations;
